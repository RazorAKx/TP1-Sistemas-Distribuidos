package sdtp1;

import java.io.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ObjetoRemoto extends UnicastRemoteObject implements RMIInterface {

    int count = 0; //este era para contar a quantidade de livros que há com um certo id
    int numeroVendas = 0;
    ArrayList<livro> ArrayListLivros = new ArrayList<>();
    ArrayList<livro> livrosVendidos = new ArrayList<>();
    String[] lines;

    public ObjetoRemoto(String name) throws java.rmi.RemoteException {
        super();
        livro l = new livro(1, "nome", "genero", "editora", "autor", 2021, 2, 10, 20);
        addLivro(l);
        ArrayListLivros = carregarLivros();
        livrosVendidos = carregarLivrosVendidos();
        try {
            Naming.rebind(name, this);
        } catch (Exception e) {
            if (e instanceof RemoteException) {
                throw (RemoteException) e;
            } else {
                throw new RemoteException(e.getMessage());
            }
        }
    }

    public void addLivro(livro l) {
        ArrayListLivros.add(l);
        System.out.println("Livro adicionado: '" + l.getNome() + "'");
        guardarLivros(ArrayListLivros);
    }

    /* public void vendeLivro(int id){
        String nome = "";
        //Remover livro da arraylist
        //E depois adicionar à lista de vendas
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                nome = ArrayListLivros.get(i).getNome();
                ArrayListLivros.remove(i);
            }
        }
        System.out.println("Livro vendido: '" + nome + "'");
    }
     */
    public ArrayList<livro> consultarLivros() {
        //adicionar a aarry list toda nao so um obj do tipo file

        return ArrayListLivros;
    }

    public ArrayList<livro> consultarPorNome(String nome) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if (nome.equals(ArrayListLivros.get(i).getNome())) {
                livros.add(ArrayListLivros.get(i));
            }
        }
        return livros;
    }

    public ArrayList<livro> consultarPorGenero(String gen) {

        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if (gen.equals(ArrayListLivros.get(i).getGenero())) {
                livros.add(ArrayListLivros.get(i));
            }
        }
        return livros;
    }

    public void eliminarLivro(int id) {
        int count = 0;
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                livros.add(ArrayListLivros.get(i));
                count++;
            }
        }
        System.out.println("eliminei " + count);
        ArrayListLivros.removeAll(livros);
        guardarLivros(ArrayListLivros);

    }

    public int quantidadeLivro(int id) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                count++;
            }
        }
        return count;
    }

    public void VenderLivro(int id) {
        int count = 0;

        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                System.out.println("Vendi " + ArrayListLivros.get(i).toString());
                livrosVendidos.add(ArrayListLivros.get(i));
                ArrayListLivros.remove(ArrayListLivros.get(i));

                break;
            }
        }
        //System.out.println("Vendi " + ArrayListLivros.get(i));
        // ArrayListLivros.removeAll(livrosVendidos);
        guardarLivros(ArrayListLivros); //Atualizar ficheiro de livros
        guardarLivrosVendidos(livrosVendidos);
    }

    public livro ProcuraLivro(int id) {
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                return ArrayListLivros.get(i);
            }

        }
        return null;
    }

    public void guardarLivros(ArrayList<livro> ArrayListLivros) {
        String tmp = "";
        FileOutputStream outputStream;
        try {
            outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\SDTP1_v5\\src\\sdtp1\\teste.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void guardarLivrosVendidos(ArrayList<livro> ArrayListLivros) {
        String tmp = "";
        FileOutputStream outputStream;
        try {
            outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\SDTP1_v5\\src\\sdtp1\\LivrosVendidos.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ArrayList<livro> carregarLivros() {
         ArrayList<livro> listaFile = new ArrayList<livro>();

        try {

            FileInputStream inputStream = new FileInputStream("C:\\SISTEMASDISTRIBUIDOS\\SDTP1_v5\\src\\sdtp1\\teste.txt");

            if (inputStream != null) {

                ObjectInputStream obj = new ObjectInputStream(inputStream);
                String s = (String) obj.readObject();

                lines = s.split("\r?\n");

                for (int i = 0; i < lines.length; i++) {

                    String[] part = lines[i].split("[|]");

                    livro l = new livro();

                    l.setId(Integer.parseInt(part[0].trim()));
                    l.setNome(part[1].trim());
                    l.setGenero(part[2].trim());
                    l.setEditora(part[3].trim());
                    l.setAutor(part[4].trim());
                    l.setAno(Integer.parseInt(part[5].trim()));
                    l.setEdicao(Integer.parseInt(part[6].trim()));
                    l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                    l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                    listaFile.add(l);
                    System.out.println("Livro:" + l.toString());

                }
                System.out.println("\n" + "Lista File: " + listaFile.toString());

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaFile;
    }
 

    public ArrayList<livro> carregarLivrosVendidos() {
        ArrayList<livro> listaFile = new ArrayList<livro>();

        try {

            FileInputStream inputStream = new FileInputStream("C:\\SISTEMASDISTRIBUIDOS\\SDTP1_v5\\src\\sdtp1\\LivrosVendidos.txt");

            if (inputStream != null) {

                ObjectInputStream obj = new ObjectInputStream(inputStream);
                String s = (String) obj.readObject();

                lines = s.split("\r?\n");

                for (int i = 0; i < lines.length; i++) {

                    String[] part = lines[i].split("[|]");

                    livro l = new livro();

                    l.setId(Integer.parseInt(part[0].trim()));
                    l.setNome(part[1].trim());
                    l.setGenero(part[2].trim());
                    l.setEditora(part[3].trim());
                    l.setAutor(part[4].trim());
                    l.setAno(Integer.parseInt(part[5].trim()));
                    l.setEdicao(Integer.parseInt(part[6].trim()));
                    l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                    l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                    listaFile.add(l);
                    System.out.println("Livro:" + l.toString());

                }
                System.out.println("\n" + "Lista File: " + listaFile.toString());

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ObjetoRemoto.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaFile;
    }
}
