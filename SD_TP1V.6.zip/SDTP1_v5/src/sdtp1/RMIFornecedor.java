package sdtp1;

public class RMIFornecedor {

}
