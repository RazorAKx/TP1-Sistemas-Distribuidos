package sdtp1;

import java.io.*;
import java.rmi.Naming;
import java.util.*;

public class RMIServidor {

    public static void main(String[] argv) throws Exception {
        ArrayList<livro> livros = new ArrayList<>();
        String name = "rmi://localhost:1099/Vendedor";
        System.setSecurityManager(new SecurityManager()); //Criar e instalar um gestor de segurança
        //rmi files permission por no policy 
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            System.out.println("Server is ready. ");

            ObjetoRemoto vendedor = new ObjetoRemoto(name);
            Naming.rebind("rmi://localhost:1099/Vendedor", vendedor);

        } catch (Exception e) {
            System.out.println("Trouble: " + e);
        }
    }
}
