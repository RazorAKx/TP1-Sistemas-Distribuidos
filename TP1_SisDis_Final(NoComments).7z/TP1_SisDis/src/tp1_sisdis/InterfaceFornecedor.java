

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;

/**
 *
 * @author bruno
 */
public interface InterfaceFornecedor extends java.rmi.Remote{
    public void printOnFornecedor(String s) throws java.rmi.RemoteException;
    //public void Escreve(String s, InterfaceRMI I) throws java.rmi.RemoteException;
}
