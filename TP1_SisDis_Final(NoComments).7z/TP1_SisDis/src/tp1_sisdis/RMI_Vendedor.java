/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;

//Main one
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;

public class RMI_Vendedor{

    public static final String TEXT_BLUE = "\u001B[36m";
    public static final String TEXT_RESET = "\u001B[0m";


    public static int RemoverLivro() {
        Scanner s = new Scanner(System.in);
        int x;
        System.out.println("Introduza o id do livro que pretende remover:");
        x = s.nextInt();
        s.nextLine();

        return x;
    }

    public static String ConsultaNome() {
        Scanner s = new Scanner(System.in);
        String nome;
        System.out.println("Introduza o nome do livro que pretende consultar:");
        nome = s.nextLine();

        return nome;
    }

    public static String ConsultaGenero() {
        Scanner s = new Scanner(System.in);
        String genero;
        System.out.println("Introduza o género do livro que pretende consultar:");
        genero = s.nextLine();

        return genero;
    }

    public static int QuantidadeLivro() {
        Scanner s = new Scanner(System.in);
        int q;
        System.out.println("Introduza o id do livro para consultar a quantidade em stock:");
        q = s.nextInt();
        s.nextLine();

        return q;
    }

    
    public static void main(String[] argv) throws Exception {
        System.setSecurityManager(new SecurityManager());

        try {
            InterfaceRMI vendedorRemoto;
            vendedorRemoto = (InterfaceRMI) Naming.lookup("rmi://localhost:1099/Vendedor");
            int option = -1;
            Scanner s = new Scanner(System.in);
            
            
            while (true) {
                do {
                    System.out.println("##########################################");
                    System.out.println("#############" + TEXT_BLUE + " Menu Vendedor " + TEXT_RESET + "##############");
                    System.out.println(TEXT_BLUE + "1" + TEXT_RESET + " - Comprar Livro");
                    System.out.println(TEXT_BLUE + "2" + TEXT_RESET + " - Vender Livro");
                    System.out.println(TEXT_BLUE + "3" + TEXT_RESET + " - Remover Livro");  //remover todos os livros com um id fornecido
                    System.out.println(TEXT_BLUE + "4" + TEXT_RESET + " - Adicionar uma certa quantidade de um produto já existente");
                    System.out.println(TEXT_BLUE + "5" + TEXT_RESET + " - Consultar Todos os Livros");
                    System.out.println(TEXT_BLUE + "6" + TEXT_RESET + " - Consultar Livro por Nome");
                    System.out.println(TEXT_BLUE + "7" + TEXT_RESET + " - Consultar Livro por Género");
                    System.out.println(TEXT_BLUE + "8" + TEXT_RESET + " - Verificar Quantidade de um dado Livro");
                    System.out.println(TEXT_BLUE + "9" + TEXT_RESET + " - Consultar Vendas efectuadas");
                    System.out.println(TEXT_BLUE + "10" + TEXT_RESET + " - Consultar Compras efetuadas");

                    System.out.println("\n0-Sair");
                    System.out.println("##########################################");
                    System.out.print("Introduza a opção: ");
                    option = s.nextInt();
                    System.out.println("");
                } while (option < 0 || option > 10);
                
                
                switch (option) {
                    
                    case 1: //1 - Comprar Livro.
                        System.out.println("Livros Disponíveis");
                        
                        System.out.println(vendedorRemoto.MostrarLivrosFornecedor());
                        
                        System.out.println("Introduza o id do livro que pretende comprar: ");
                        int  idcompra = s.nextInt();
                        s.nextLine();
                        System.out.println("Introduza o preço  de venda para este livro:");
                        float preco = s.nextFloat();
                        s.nextLine();
                        vendedorRemoto.ComprarLivro(idcompra,preco);
                        // vendedorRemoto.addLivro(AdicionarLivro());
                        System.out.println("Livro adicionado com sucesso.\n");
                        break;
                    case 2: //2 - Vender Livro
                        int id, q;
                        System.out.println("Introduza a quantidade de livros a vender:");
                        q = s.nextInt();
                        s.nextLine();
                        for (int i = 0; i < q; i++) {
                            System.out.println("Introduza o id do livro que vai vender:");
                            id = s.nextInt();
                            s.nextLine();
                            vendedorRemoto.VenderLivro(id);
                        }
                        System.out.println("Venda efetuada.\n");
                        break;
                    case 3: //3 - Remover Livro
                        vendedorRemoto.eliminarLivro(RemoverLivro());
                        System.out.println("Livro removido da livraria.\n");
                        break;
                    case 4://4- Adicionar uma quantidade de produtos já existente
                        int quantidade,
                         IdLivro;
                        System.out.println("Introduza a quantidade de livros que pretende adicionar");
                        quantidade = s.nextInt();
                        s.nextLine();
                        System.out.println("Introduza o id do livros que pretende adicionar");
                        IdLivro = s.nextInt();
                        s.nextLine();
                        for (int j = 0; j < quantidade; j++) {
                            vendedorRemoto.addLivro(vendedorRemoto.ProcuraLivro(IdLivro));
                        }
                        System.out.println("Livros adicionados com sucesso.\n");
                        break;
                    case 5: //5 - Consultar Todos os Livro
                        System.out.println(vendedorRemoto.consultarLivros());
                        System.out.println("\n");
                        break;
                    case 6: //6 - Consultar Livro por Nome
                        System.out.println(vendedorRemoto.consultarPorNome(ConsultaNome()));
                        System.out.println("\n");
                        break;
                    case 7: //7 - Consulta Livro por Género
                        System.out.println(vendedorRemoto.consultarPorGenero(ConsultaGenero()));
                        System.out.println("\n");
                        break;
                    case 8: //8 - Verificar Quantidade de um dado Livro
                        System.out.println("Exitem " + vendedorRemoto.quantidadeLivro(QuantidadeLivro()) + " Livros");
                        System.out.println("\n");
                        break;
                    case 9: //9 - Consultar Vendas efetuadas // e para listar os livros
                        System.out.println("Livros Vendidos: " + vendedorRemoto.carregarLivrosVendidos());
                        System.out.println("\n");
                        break;
                    case 10: //10 - Consultar Compras efetuadas  // e para listar os livros
                        System.out.println("Livros Comprados: " + vendedorRemoto.carregarLivrosComprados());
                        System.out.println("\n");
                        break;
                    case 0: //0 - Sair
                        System.out.println("Obrigado, volte sempre :)\n");
                        System.exit(0);
                        //é ncessário fechar o rmi ou so deixar ?
                        break;
                }
            }

        } catch (RemoteException re) {

            System.out.println("RemoteException");
            System.out.println(re.getMessage());
        }
    }
}

