/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;
//Main one

import java.io.*;
import java.rmi.Naming;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RMIServer extends java.rmi.server.UnicastRemoteObject implements InterfaceServidor {

    private ArrayList<InterfaceFornecedor> ArrayFornecedor = new ArrayList();
    
    public RMIServer() throws java.rmi.RemoteException {
        super();
    }

    private static InterfaceFornecedor client;

    public void subscribe(String name,InterfaceFornecedor f) throws java.rmi.RemoteException {
        System.out.println("Subscribing " + name);
        client = f;
        ArrayList<livro> listanova = new ArrayList<livro>();
        
        listanova=carregarLivros();
        
        if(listanova.isEmpty()){
            for (int i = 0; i < ArrayFornecedor.size(); i++) {
                client = ArrayFornecedor.get(i);
                client.printOnFornecedor("Preciso de livros");
            }
            
        }
    }

        public ArrayList<livro> carregarLivros() {
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
        String[] lines;
        try {
            if (file.createNewFile()) {
                return listaFile;
            } else {
                try {
                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {

                        ObjectInputStream obj = new ObjectInputStream(inputStream);

                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");
                           
                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            if (part[i] != null) {

                                livro l = new livro();

                                l.setId(Integer.parseInt(part[0].trim()));
                                l.setNome(part[1].trim());
                                l.setGenero(part[2].trim());
                                l.setEditora(part[3].trim());
                                l.setAutor(part[4].trim());
                                l.setAno(Integer.parseInt(part[5].trim()));
                                l.setEdicao(Integer.parseInt(part[6].trim()));
                                l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                                l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                                listaFile.add(l);
                                
                            }
                        }
                        obj.close();
                        
                    }
                    inputStream.close();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaFile;
    }

    public static void main(String[] argv) throws Exception {

        String name = "rmi://localhost:1099/Vendedor";
        System.setSecurityManager(new SecurityManager()); //Criar e instalar um gestor de segurança
        //rmi files permission por no policy 
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            RMIServer s = new RMIServer();
            Naming.rebind("hello", s);
            System.out.println("Server is ready. ");

            RemoteObject vendedor = new RemoteObject(name);
            Naming.rebind("rmi://localhost:1099/Vendedor", vendedor);

        } catch (Exception e) {
            System.out.println("Trouble: " + e);
        }
    }
}
