/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;

import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RemoteObject extends UnicastRemoteObject implements InterfaceRMI {

    int count = 0; //este era para contar a quantidade de livros que há com um certo id
    int numeroVendas = 0;
    ArrayList<livro> ArrayListLivros = new ArrayList<>();
    ArrayList<livro> livrosVendidos = new ArrayList<>();
    ArrayList<livro> LivrosFornecedor = new ArrayList<>();
    ArrayList<livro> LivrosComprados = new ArrayList<>();

    String[] lines;

    private static InterfaceRMI V;

    public RemoteObject(String name) throws java.rmi.RemoteException {
        super();

        ArrayListLivros = carregarLivros();
        livrosVendidos = carregarLivrosVendidos();
        LivrosFornecedor = carregarLivrosFornecedor();
        LivrosComprados = carregarLivrosComprados();

        try {
            Naming.rebind(name, this);
        } catch (Exception e) {
            if (e instanceof RemoteException) {
                throw (RemoteException) e;
            } else {
                throw new RemoteException(e.getMessage());
            }
        }
    }

    public ArrayList<livro> MostrarLivrosFornecedor() {
        return LivrosFornecedor;
    }

    public void ComprarLivro(int id, float p) {

        for (int i = 0; i < LivrosFornecedor.size(); i++) {
            if ((LivrosFornecedor.get(i).getId()) == id) {
                LivrosFornecedor.get(i).setPrecoVenda(p);
                LivrosComprados.add(LivrosFornecedor.get(i));
                ArrayListLivros.add(LivrosFornecedor.get(i));
                LivrosFornecedor.remove(LivrosFornecedor.get(i));
                break;
            }
        }
        guardarLivros(ArrayListLivros); //Atualizar ficheiro de livros
        guardarLivrosComprados(LivrosComprados);
        guardarLivrosFornecedor(LivrosFornecedor);

    }

    public void addLivro(livro l) {
        LivrosFornecedor.add(l);
        guardarLivrosFornecedor(LivrosFornecedor);
    }

    public ArrayList<livro> consultarLivros() {
        //adicionar a aarry list toda nao so um obj do tipo file
        return ArrayListLivros;
    }

    public ArrayList<livro> consultarPorNome(String nome) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if (nome.equals(ArrayListLivros.get(i).getNome())) {
                livros.add(ArrayListLivros.get(i));
            }
        }
        return livros;
    }

    public ArrayList<livro> consultarPorGenero(String gen) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if (gen.equals(ArrayListLivros.get(i).getGenero())) {
                livros.add(ArrayListLivros.get(i));
            }
        }
        return livros;
    }

    public void eliminarLivro(int id) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                livros.add(ArrayListLivros.get(i));
            }
        }
        ArrayListLivros.removeAll(livros);
        guardarLivros(ArrayListLivros);

    }

    public void eliminarLivroFornecedor(int id) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < LivrosFornecedor.size(); i++) {
            if ((LivrosFornecedor.get(i).getId()) == id) {
                livros.add(LivrosFornecedor.get(i));
                
            }
        }
        LivrosFornecedor.removeAll(livros);
        guardarLivros(LivrosFornecedor);

    }

    public int quantidadeLivro(int id) {
        ArrayList<livro> livros = new ArrayList<>();
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                count++;
            }
        }
        return count;
    }

    public void VenderLivro(int id) {
        int count = 0;

        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                livrosVendidos.add(ArrayListLivros.get(i));
                ArrayListLivros.remove(ArrayListLivros.get(i));

                break;
            }
        }

        guardarLivros(ArrayListLivros); //Atualizar ficheiro de livros
        guardarLivrosVendidos(livrosVendidos);

    }

    public livro ProcuraLivro(int id) {
        for (int i = 0; i < ArrayListLivros.size(); i++) {
            if ((ArrayListLivros.get(i).getId()) == id) {
                return ArrayListLivros.get(i);
            }

        }
        return null;
    }

    public void guardarLivros(ArrayList<livro> ArrayListLivros){
        String tmp = "";
        FileOutputStream outputStream;
        
       
        if (ArrayListLivros.isEmpty()) { 
             File myObj = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt"); 
             myObj.delete();
             
        }else{
        
  
        try {
            outputStream = new FileOutputStream("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
            outputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }

    public void guardarLivrosFornecedor(ArrayList<livro> ArrayListLivros) {
        String tmp = "";
        FileOutputStream outputStream;
        
        if (ArrayListLivros.isEmpty()) { 
             File myObj = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt"); 
             myObj.delete();
             
        }else{
        
        
        try {
            outputStream = new FileOutputStream("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
            outputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }

    public void guardarLivrosVendidos(ArrayList<livro> ArrayListLivros) {
        String tmp = "";
        FileOutputStream outputStream;
        
        if (ArrayListLivros.isEmpty()) { 
             File myObj = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt"); 
             myObj.delete();
             
        }else{
        
        
        try {
            outputStream = new FileOutputStream("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
            outputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }

    public void guardarLivrosComprados(ArrayList<livro> ArrayListLivros) {
        String tmp = "";
        FileOutputStream outputStream;
        
        if (ArrayListLivros.isEmpty()) { 
             File myObj = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt"); 
             myObj.delete();
             
        }else{
        
        try {
            outputStream = new FileOutputStream("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt");
            ObjectOutputStream obj = new ObjectOutputStream(outputStream);
            for (int i = 0; i < ArrayListLivros.size(); i++) {
                tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                        + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                        + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
            }
            obj.writeObject(tmp);
            obj.flush();
            obj.close();
            outputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }

    public ArrayList<livro> carregarLivros() {
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
        try {
            if (file.createNewFile()) {
                return listaFile;
            } else {
                try {
                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {

                        ObjectInputStream obj = new ObjectInputStream(inputStream);

                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");
                           
                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            if (part[i] != null) {

                                livro l = new livro();

                                l.setId(Integer.parseInt(part[0].trim()));
                                l.setNome(part[1].trim());
                                l.setGenero(part[2].trim());
                                l.setEditora(part[3].trim());
                                l.setAutor(part[4].trim());
                                l.setAno(Integer.parseInt(part[5].trim()));
                                l.setEdicao(Integer.parseInt(part[6].trim()));
                                l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                                l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                                listaFile.add(l);
                                 
                            }
                        }
                        obj.close();
                        
                       
                    }
                     inputStream.close();
                     
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosVendidos() {
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt");

        try {
            if (file.createNewFile()) {

                return listaFile;

            } else {

                try {

                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {

                        ObjectInputStream obj = new ObjectInputStream(inputStream);

                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");

                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                            

                        }
                        obj.close();
                        

                    }
                     inputStream.close();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosComprados() {
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt");

        try {
            if (file.createNewFile()) {

                return listaFile;

            } else {

                try {

                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {

                        ObjectInputStream obj = new ObjectInputStream(inputStream);

                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");

                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                            

                        }
                        obj.close();
                       

                    }
                     inputStream.close();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosFornecedor() {
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\Users\\bruno\\Downloads\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt");

        try {
            if (file.createNewFile()) {

                return listaFile;

            } else {

                try {

                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {

                        ObjectInputStream obj = new ObjectInputStream(inputStream);

                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");

                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                            

                        }
                        obj.close();
                        

                    }
                     inputStream.close();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(RemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaFile;
    }
    
}
