/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;

/**
 *
 * @author bruno
 */
public interface InterfaceServidor extends java.rmi.Remote{
    public void subscribe(String name, InterfaceFornecedor f) throws java.rmi.RemoteException;
}
