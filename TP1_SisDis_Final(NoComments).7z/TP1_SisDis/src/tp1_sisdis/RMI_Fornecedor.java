/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_sisdis;


import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;


public class RMI_Fornecedor extends java.rmi.server.UnicastRemoteObject implements InterfaceFornecedor{
    
    public RMI_Fornecedor() throws java.rmi.RemoteException{
        super();
    }
    
    
    
    public static final String TEXT_RED = "\u001B[31m";
    public static final String TEXT_RESET = "\u001B[0m";

    public static livro AdicionarLivro() {
        livro l;
        Scanner s = new Scanner(System.in);
        String nome = "", autor = "", genero = "", editora = "";
        int id = 0, ano, edicao;
        float precocompra = 0, precovenda = 0;
        System.out.println("##########################################");
        System.out.println("############ Adicionar Livro #############");
        System.out.print("Id:");
        id = s.nextInt();
        s.nextLine();
        System.out.print("Nome:");
        nome = s.nextLine();
        System.out.print("Género:");
        genero = s.nextLine();
        System.out.print("Editora:");
        editora = s.nextLine();
        System.out.print("Autor(a):");
        autor = s.nextLine();
        System.out.print("Ano:");
        ano = s.nextInt();
        s.nextLine();
        System.out.print("Edição:");
        edicao = s.nextInt();
        s.nextLine();
        System.out.print("Preço de Compra:");
        precocompra = s.nextFloat();
        s.nextLine();
        System.out.println("##########################################");
        l = new livro(id, nome, genero, editora, autor, ano, edicao, precocompra, -1);

        return l;
    }

    public static int RemoverLivro() {
        Scanner s = new Scanner(System.in);
        int x;
        System.out.println("Introduza o id do livro que pretende remover:");
        x = s.nextInt();
        s.nextLine();

        return x;
    }

    public static String ConsultaNome() {
        Scanner s = new Scanner(System.in);
        String nome;
        System.out.println("Introduza o nome do livro que pretende consultar:");
        nome = s.nextLine();

        return nome;
    }

    public static String ConsultaGenero() {
        Scanner s = new Scanner(System.in);
        String genero;
        System.out.println("Introduza o género do livro que pretende consultar:");
        genero = s.nextLine();

        return genero;
    }

    public static int QuantidadeLivro() {
        Scanner s = new Scanner(System.in);
        int q;
        System.out.println("Introduza o id do livro para consultar a quantidade em stock:");
        q = s.nextInt();
        s.nextLine();

        return q;
    }

    public void printOnFornecedor(String s) throws java.rmi.RemoteException {
        System.out.println("Message from server: " + s);
    }
    
   /* public void Escreve(String s, InterfaceRMI I) throws java.rmi.RemoteException{
        V = I;
        I.printOnVendedor("ola eu quero 20");
    }
    */
    
    public static void main(String[] argv) throws Exception {
        System.setSecurityManager(new SecurityManager());

        try {
            InterfaceRMI vendedorRemoto;
            vendedorRemoto = (InterfaceRMI) Naming.lookup("rmi://localhost:1099/Vendedor");
            InterfaceServidor interfaceServer= (InterfaceServidor)Naming.lookup("hello");
            RMI_Fornecedor f =new RMI_Fornecedor();
            interfaceServer.subscribe("192.168.1.106",(InterfaceFornecedor)f);
            
            int option = -1;
            Scanner s = new Scanner(System.in);

            
            while (true) {
                do {
                    System.out.println("##########################################");
                    System.out.println("#############" + TEXT_RED + " Menu Fornecedor " + TEXT_RESET + "##############");
                    System.out.println(TEXT_RED + "1" + TEXT_RESET + " - Adicionar Livro");
                    System.out.println(TEXT_RED + "2" + TEXT_RESET + " - Remover Livro");  //remover todos os livros com um id fornecido
                    System.out.println(TEXT_RED + "3" + TEXT_RESET + " - Adicionar uma certa quantidade de um produto já existente");
                    System.out.println(TEXT_RED + "4" + TEXT_RESET + " - Consultar Todos os Livros");
                    System.out.println(TEXT_RED + "5" + TEXT_RESET + " - Consultar Vendas efectuadas");


                    System.out.println("\n0-Sair");
                    System.out.println("##########################################");
                    System.out.print("Introduza a opção: ");
                    option = s.nextInt();
                    System.out.println("");
                } while (option < 0 || option > 5);

                switch (option) {
                    case 1: //1 - Adicionar Livro.
                        vendedorRemoto.addLivro(AdicionarLivro());
                        System.out.println("Livro adicionado com sucesso.\n");
                        break;
                    case 2: //3 - Remover Livro
                        vendedorRemoto.eliminarLivroFornecedor(RemoverLivro());
                        System.out.println("Livro removido da livraria.\n");
                        break;
                    case 3://4- Adicionar uma quantidade de produtos já existente
                        int quantidade,IdLivro;
                        System.out.println("Introduza a quantidade de livros que pretende adicionar");
                        quantidade = s.nextInt();
                        s.nextLine();
                        System.out.println("Introduza o id do livros que pretende adicionar");
                        IdLivro = s.nextInt();
                        s.nextLine();
                        for (int j = 0; j < quantidade; j++) {
                            vendedorRemoto.addLivro(vendedorRemoto.ProcuraLivro(IdLivro));
                        }
                        System.out.println("Livros adicionados com sucesso.\n");
                        break;
                    case 4: //5 - Consultar Todos os Livro
                        System.out.println(vendedorRemoto.MostrarLivrosFornecedor());
                        System.out.println("\n");
                        break;
                    case 5: //9 - Consultar Vendas efetuadas // e para listar os livros
                        System.out.println("Livros Vendidos: " + vendedorRemoto.carregarLivrosComprados());
                        break;
                    case 0: //0 - Sair
                        System.out.println("Obrigado, volte sempre :)\n");
                        System.exit(0);
                      
                        break;
                }
            }

        } catch (RemoteException re) {

            System.out.println("RemoteException");
            System.out.println(re.getMessage());
        }
    }
    
}
