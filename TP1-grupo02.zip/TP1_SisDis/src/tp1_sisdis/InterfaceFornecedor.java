package tp1_sisdis;
//Interface com o método para o fornecedor para o callback
public interface InterfaceFornecedor extends java.rmi.Remote{
    public void printOnFornecedor(String s) throws java.rmi.RemoteException;
}
