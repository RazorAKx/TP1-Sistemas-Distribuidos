package tp1_sisdis;
//Interface com o método para o servidor para o callback
public interface InterfaceServidor extends java.rmi.Remote{
    public void subscribe(String name, InterfaceFornecedor f) throws java.rmi.RemoteException;
}
