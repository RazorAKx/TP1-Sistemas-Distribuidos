package tp1_sisdis;

import java.io.*;
import java.rmi.Naming;
import java.util.*;
import java.util.logging.*;

public class RMIServer extends java.rmi.server.UnicastRemoteObject implements InterfaceServidor {
    
    //Construtor
    public RMIServer() throws java.rmi.RemoteException {
        super();
    }

    private static InterfaceFornecedor client; 
    
    //Método de callback que dá informação ao fornecedor de que o vendedor está com falta de stock
    public void subscribe(String name,InterfaceFornecedor f) throws java.rmi.RemoteException {
        System.out.println("Subscribing " + name);
        
        client = f;
        ArrayList<livro> listanova = new ArrayList<livro>();
        listanova=carregarLivros(); 
        
        if(listanova.isEmpty()){
        
            client.printOnFornecedor("Preciso de livros");//Mensagem para o fornecedor
        }
    }
    public ArrayList<livro> carregarLivros() {//Método para carregar livros do ficheiro do vendedor para a respetiva ArrayList
        
        ArrayList<livro> listaFile = new ArrayList<livro>();//Lista que ira conter o conteúdo carregado do devido ficheiro
        
        File file = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
        String[] lines;
        try {
            if (file.createNewFile()) {// Se for possível criar um ficheiro novo devolvemos uma lista vazia
                return listaFile;
            }else {
                try {
                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) { //Verificar se o ficheiro está vazio
                        
                        //Adicionar o conteúdo lido do ficheiro à ArrayList 
                        ObjectInputStream obj = new ObjectInputStream(inputStream);
                        String s = (String) obj.readObject();
                        lines = s.split("\r?\n");
                           
                        for (int i = 0; i < lines.length; i++) {
                            String[] part = lines[i].split("[|]");
                            
                            if (part[i] != null) {
                                livro l = new livro();

                                l.setId(Integer.parseInt(part[0].trim()));
                                l.setNome(part[1].trim());
                                l.setGenero(part[2].trim());
                                l.setEditora(part[3].trim());
                                l.setAutor(part[4].trim());
                                l.setAno(Integer.parseInt(part[5].trim()));
                                l.setEdicao(Integer.parseInt(part[6].trim()));
                                l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                                l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                                listaFile.add(l);
                            }
                        }
                        obj.close();
                    }
                    inputStream.close();
                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());                
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());  
                } catch (ClassNotFoundException ex) {
                    System.out.println(ex.getMessage());  
                }
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
        return listaFile;
    }

    public static void main(String[] argv) throws Exception {
        
        
        String name = "rmi://localhost:1099/Vendedor";//Registar bjecto remoto no serviço de nomes
        System.setSecurityManager(new SecurityManager()); //Criar e instalar um gestor de segurança
        try {
            
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            RMIServer s = new RMIServer();
            Naming.rebind("hello", s);
            System.out.println("Server is ready. ");

            RemoteObject vendedor = new RemoteObject(name);
            Naming.rebind("rmi://localhost:1099/Vendedor", vendedor);

        } catch (Exception e) {
            System.out.println("Trouble: " + e);
        }
    }
}
