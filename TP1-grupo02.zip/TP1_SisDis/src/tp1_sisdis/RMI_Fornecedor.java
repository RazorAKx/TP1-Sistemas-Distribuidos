package tp1_sisdis;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;

public class RMI_Fornecedor extends java.rmi.server.UnicastRemoteObject implements InterfaceFornecedor{
    
    //Construtor
    public RMI_Fornecedor() throws java.rmi.RemoteException{
        super();
    }
    //Variáveis para colorir o texto menu 
    public static final String TEXT_RED = "\u001B[31m";
    public static final String TEXT_RESET = "\u001B[0m";

    public static livro AdicionarLivro() { //Método para para ler os atributos da classe livro 
        livro l;
        Scanner s = new Scanner(System.in);
        String nome = "", autor = "", genero = "", editora = "";
        int id = 0, ano, edicao;
        float precocompra = 0, precovenda = 0;
        System.out.println("##########################################");
        System.out.println("############ Adicionar Livro #############");
        System.out.print("Id:");
        id = s.nextInt();
        s.nextLine();
        System.out.print("Nome:");
        nome = s.nextLine();
        System.out.print("Género:");
        genero = s.nextLine();
        System.out.print("Editora:");
        editora = s.nextLine();
        System.out.print("Autor(a):");
        autor = s.nextLine();
        System.out.print("Ano:");
        ano = s.nextInt();
        s.nextLine();
        System.out.print("Edição:");
        edicao = s.nextInt();
        s.nextLine();
        System.out.print("Preço de Compra:");
        precocompra = s.nextFloat();
        s.nextLine();
        System.out.println("##########################################");
        l = new livro(id, nome, genero, editora, autor, ano, edicao, precocompra, -1);

        return l;
    }

    public static int RemoverLivro() { //Método para ler o id do livro que será removido
        Scanner s = new Scanner(System.in);
        int x;
        System.out.println("Introduza o id do livro que pretende remover:");
        x = s.nextInt();
        s.nextLine();

        return x;
    }

    public void printOnFornecedor(String s) throws java.rmi.RemoteException {//Método que é chamado para enviar mensagem do servidor ao fornecedor
        System.out.println("Mensagem do servidor: " + s);
    }

    public static void main(String[] argv) throws Exception {
        System.setSecurityManager(new SecurityManager());//Criar e instalar um gestor de segurança

        try {
            InterfaceRMI vendedorRemoto;
            vendedorRemoto = (InterfaceRMI) Naming.lookup("rmi://localhost:1099/Vendedor");//obter a referência ao objecto remoto
            InterfaceServidor interfaceServer = (InterfaceServidor)Naming.lookup("hello");
            RMI_Fornecedor f =new RMI_Fornecedor();
            interfaceServer.subscribe("192.168.1.106",(InterfaceFornecedor)f);
            
            int option = -1;
            Scanner s = new Scanner(System.in);

            while (true) { // O programa corre até ler a opção válida
                do {// Menu do fornecedor
                    System.out.println("##########################################");
                    System.out.println("#############" + TEXT_RED + " Menu Fornecedor " + TEXT_RESET + "############");
                    System.out.println(TEXT_RED + "1" + TEXT_RESET + " - Adicionar Livro");
                    System.out.println(TEXT_RED + "2" + TEXT_RESET + " - Remover Livro");  //remover todos os livros com um id fornecido
                    System.out.println(TEXT_RED + "3" + TEXT_RESET + " - Adicionar uma certa quantidade de um produto já existente");
                    System.out.println(TEXT_RED + "4" + TEXT_RESET + " - Consultar Todos os Livros");
                    System.out.println(TEXT_RED + "5" + TEXT_RESET + " - Consultar Vendas efectuadas");

                    System.out.println("\n"+ TEXT_RED + "0" + TEXT_RESET + " - Sair");
                    System.out.println("##########################################");
                    System.out.print("Introduza a opção: ");
                    option = s.nextInt();
                    System.out.println("");
                } while (option < 0 || option > 5);

                switch (option) {
                    case 1: //1 - Adicionar Livro.
                        vendedorRemoto.addLivro(AdicionarLivro());
                        System.out.println("Livro adicionado com sucesso.\n");
                        break;
                    case 2: //2 - Remover Livro
                        vendedorRemoto.eliminarLivroFornecedor(RemoverLivro());
                        System.out.println("Livro removido da livraria.\n");
                        break;
                    case 3://3- Adicionar uma quantidade de produtos já existente
                        int quantidade,IdLivro;
                        System.out.println("Introduza a quantidade de livros que pretende adicionar");
                        quantidade = s.nextInt();
                        s.nextLine();
                        System.out.println("Introduza o id de livros que pretende adicionar");
                        IdLivro = s.nextInt();
                        s.nextLine();
                        for (int j = 0; j < quantidade; j++) {
                            vendedorRemoto.addLivro(vendedorRemoto.ProcuraLivroFornecedor(IdLivro));
                        }
                        System.out.println("Livros adicionados com sucesso.\n");
                        break;
                    case 4: //4 - Consultar Todos os Livro
                        System.out.println(vendedorRemoto.MostrarLivrosFornecedor());
                        System.out.println("\n");
                        break;
                    case 5: //5 - Consultar Vendas efetuadas // e para listar os livros
                        System.out.println("Livros Vendidos: " + vendedorRemoto.carregarLivrosComprados());
                        break;
                    case 0: //0 - Sair
                        System.out.println("Obrigado, volte sempre :)\n");
                        System.exit(0); 
                        break;
                }
            }
        } catch (RemoteException re) {
            System.out.println("RemoteException");
            System.out.println(re.getMessage());
        }
    }
}
