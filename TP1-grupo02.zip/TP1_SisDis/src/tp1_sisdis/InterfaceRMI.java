package tp1_sisdis;

import java.util.*;
//Interface com os metodos para o objeto remoto
public interface InterfaceRMI extends java.rmi.Remote{
    public void addLivro (livro l) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarLivros() throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorNome(String nome) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorGenero(String gen) throws java.rmi.RemoteException;
    public void eliminarLivro(int id) throws java.rmi.RemoteException;
    public int quantidadeLivro(int id) throws java.rmi.RemoteException;
    public void VenderLivro(int id) throws java.rmi.RemoteException;
    public livro ProcuraLivro(int id) throws java.rmi.RemoteException;
    public livro ProcuraLivroFornecedor(int id) throws java.rmi.RemoteException;
    public ArrayList<livro> carregarLivrosComprados() throws java.rmi.RemoteException;
    public ArrayList<livro> carregarLivrosVendidos() throws java.rmi.RemoteException;
    public void eliminarLivroFornecedor(int id) throws java.rmi.RemoteException;
    public ArrayList<livro> MostrarLivrosFornecedor() throws java.rmi.RemoteException;
    public void ComprarLivro(int id, float p) throws java.rmi.RemoteException;  
}