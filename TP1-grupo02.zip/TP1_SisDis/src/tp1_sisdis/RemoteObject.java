package tp1_sisdis;

import java.io.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.logging.*;

public class RemoteObject extends UnicastRemoteObject implements InterfaceRMI {

    int count = 0, numeroVendas = 0;
    ArrayList<livro> LivrosVendedor = new ArrayList<>();//Guarda os livros do vendedor em stock
    ArrayList<livro> LivrosVendidos = new ArrayList<>();//Guarda os livros que foram vendidos pelo vendedor
    ArrayList<livro> LivrosFornecedor = new ArrayList<>();//Guarda os livros que o fornecedor tem em stock
    ArrayList<livro> LivrosComprados = new ArrayList<>();//Guarda os livros que o vendedor comprou ao fornecedor
    String[] lines;

    //Construtor
    public RemoteObject(String name) throws java.rmi.RemoteException {
        super();

        //Carregar todos as listas dos devidos fiheiros
        LivrosVendedor = carregarLivros();
        LivrosVendidos = carregarLivrosVendidos();
        LivrosFornecedor = carregarLivrosFornecedor();
        LivrosComprados = carregarLivrosComprados();

        try {
            //o construtor informa o RMI registry de que este objecto está disponível com o name recebido
            Naming.rebind(name, this);
        } catch (Exception e) {
            if (e instanceof RemoteException) {
                throw (RemoteException) e;
            } else {
                throw new RemoteException(e.getMessage());
            }
        }
    }

    public ArrayList<livro> MostrarLivrosFornecedor() {//Método do objeto remoto para mostrar os livros disponiveis do fornecedor
        return LivrosFornecedor;
    }

    public void ComprarLivro(int id, float p) {//Método do objeto remoto para comprar um livro ao fornecedor dado um id e o preço pelo qual será vendido

        for (int i = 0; i < LivrosFornecedor.size(); i++) {
            if ((LivrosFornecedor.get(i).getId()) == id) {
                LivrosFornecedor.get(i).setPrecoVenda(p);
                LivrosComprados.add(LivrosFornecedor.get(i));
                LivrosVendedor.add(LivrosFornecedor.get(i));
                LivrosFornecedor.remove(LivrosFornecedor.get(i));
                break;
            }
        }
        guardarLivros(LivrosVendedor); //Atualizar o ficheiro de livros do vendedor
        guardarLivrosComprados(LivrosComprados);//Atualizar o ficheiro de livros comprados ao fornecedor
        guardarLivrosFornecedor(LivrosFornecedor);//Atualizar o ficheiro de livros em stock do fornecedor
    }

    public void addLivro(livro l) {//Método para adicionar um livro ao stock do fornecedor 
        LivrosFornecedor.add(l);//Adicionar o livro à lista dos livros que o fornecedor contém
        guardarLivrosFornecedor(LivrosFornecedor);//Atualizar o ficheiro de livros em stock do fornecedor
    }

    public ArrayList<livro> consultarLivros() { // Método para consultar os livros do vendedor (Retorna a lista que contém os livros do vendedor)
        return LivrosVendedor;
    }

    public ArrayList<livro> consultarPorNome(String nome) {//Método para consultar os livros do vendedor por nome
        ArrayList<livro> livros = new ArrayList<>();
        //Percorrer a ArrayList do vendedor e verificar se o nome é igual guardando todos os elementos resultantes numa nova lista
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if (nome.equals(LivrosVendedor.get(i).getNome())) {
                livros.add(LivrosVendedor.get(i));
            }
        }
        return livros;
    }

    public ArrayList<livro> consultarPorGenero(String gen) {//Método para consultar os livros do vendedor por género
        ArrayList<livro> livros = new ArrayList<>();
        //Percorrer a ArrayList do vendedor e verificar se o género é igual guardando todos os elementos resultantes numa nova lista
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if (gen.equals(LivrosVendedor.get(i).getGenero())) {
                livros.add(LivrosVendedor.get(i));
            }
        }
        return livros;
    }

    public void eliminarLivro(int id) {//Método para eliminar todos os livros do vendedor dado o seu id    
        ArrayList<livro> livros = new ArrayList<>();
        //Colocar todos os livros com o id encontrados numa lista nova
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if ((LivrosVendedor.get(i).getId()) == id) {
                livros.add(LivrosVendedor.get(i));
            }
        }
        LivrosVendedor.removeAll(livros); //Remover da lista original todos os elementos que estão na lista nova
        guardarLivros(LivrosVendedor);//Atualizar o ficheiro de livros do vendedor

    }

    public void eliminarLivroFornecedor(int id) {// Método para eliminar todos os livros do fornecedor dado o seu id 
        ArrayList<livro> livros = new ArrayList<>();
        //Colocar todos os livros com o id encontrados numa lista nova
        for (int i = 0; i < LivrosFornecedor.size(); i++) {
            if ((LivrosFornecedor.get(i).getId()) == id) {
                livros.add(LivrosFornecedor.get(i));
            }
        }
        LivrosFornecedor.removeAll(livros);//Remover da lista original todos os elementos que estão na lista nova
        guardarLivros(LivrosFornecedor);//Atualizar o ficheiro de livros do vendedor
    }

    public int quantidadeLivro(int id) { //Método que devolve a quantidade de livros do vendedor dado o seu id
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if ((LivrosVendedor.get(i).getId()) == id) {
                count++;
            }
        }
        return count;
    }

    public void VenderLivro(int id) { //Método que dado um id de livro vende o mesmo, isto é remove o objeto da ArrayList 
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if ((LivrosVendedor.get(i).getId()) == id) {
                LivrosVendidos.add(LivrosVendedor.get(i));
                LivrosVendedor.remove(LivrosVendedor.get(i));
                break;
            }
        }
        guardarLivros(LivrosVendedor);//Atualizar o ficheiro de livros do vendedor
        guardarLivrosVendidos(LivrosVendidos);//Guardar no ficheiro de livros vendidos pelo vendedor
    }

    public livro ProcuraLivro(int id) { //Método que para procurar um livro dado o seu id
        for (int i = 0; i < LivrosVendedor.size(); i++) {
            if ((LivrosVendedor.get(i).getId()) == id) {
                return LivrosVendedor.get(i);
            }
        }
        return null;
    }
    public livro ProcuraLivroFornecedor(int id) { //Método que para procurar um livro dado o seu id
        for (int i = 0; i < LivrosFornecedor.size(); i++) {
            if ((LivrosFornecedor.get(i).getId()) == id) {
                return LivrosFornecedor.get(i);
            }
        }
        return null;
    }

    public void guardarLivros(ArrayList<livro> ArrayListLivros) { //Método que guarda os livros do vendedor no determinado ficheiro 

        String tmp = "";
        FileOutputStream outputStream;
        //Caso a ArrayList recebida esteja vazia elimina o ficheiro para quando é carregado não se leia "lixo"
        if (ArrayListLivros.isEmpty()) {
            File myObj = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
            myObj.delete();
        } else {
            //Abrir o ficheiro
            //Percorrer a ArrayList objeto a objeto 
            //Para cada objeto adiciona-se a uma string temporária(tmp) e posteriormente escrver no ficheiro
            try {
                outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
                ObjectOutputStream obj = new ObjectOutputStream(outputStream);
                for (int i = 0; i < ArrayListLivros.size(); i++) {
                    tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                            + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                            + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
                }
                obj.writeObject(tmp);
                
                obj.flush();
                obj.close();
                outputStream.close();
            }catch (FileNotFoundException ex) {
               System.out.println(ex.getMessage());
            }catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void guardarLivrosFornecedor(ArrayList<livro> ArrayListLivros) {//Método que guarda os livros do fornecedor determinado ficheiro 
      
        String tmp = "";
        FileOutputStream outputStream;
        //Caso a ArrayList recebida esteja vazia elimina o ficheiro para quando é carregado não se leia "lixo"
        if (ArrayListLivros.isEmpty()) {
            File myObj = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt");
            myObj.delete();
        } else {
            //Abrir o ficheiro
            //Percorrer a ArrayList objeto a objeto 
            //Para cada objeto adiciona-se a uma string temporária(tmp) e posteriormente escrver no ficheiro
            try {
                outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt");
                ObjectOutputStream obj = new ObjectOutputStream(outputStream);
                for (int i = 0; i < ArrayListLivros.size(); i++) {
                    tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                            + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                            + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
                }
                obj.writeObject(tmp);
                obj.flush();
                obj.close();
                outputStream.close();
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage());
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void guardarLivrosVendidos(ArrayList<livro> ArrayListLivros) {//Método que guarda os livros do vendedor que foram vendidos no determinado ficheiro 
        String tmp = "";
        FileOutputStream outputStream;
        //Caso a ArrayList recebida esteja vazia elimina o ficheiro para quando é carregado não se leia "lixo"
        if (ArrayListLivros.isEmpty()) {
            File myObj = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt");
            myObj.delete();
        } else {
            //Abrir o ficheiro
            //Percorrer a ArrayList objeto a objeto 
            //Para cada objeto adiciona-se a uma string temporária(tmp) e posteriormente escrver no ficheiro
            try {
                outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt");
                ObjectOutputStream obj = new ObjectOutputStream(outputStream);
                for (int i = 0; i < ArrayListLivros.size(); i++) {
                    tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                            + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                            + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
                }
                obj.writeObject(tmp);
                obj.flush();
                obj.close();
                outputStream.close();
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage());
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void guardarLivrosComprados(ArrayList<livro> ArrayListLivros) {//Método que guarda os livros do fornecedor que foram vendidos ao vendedor no determinado ficheiro 
        String tmp = "";
        FileOutputStream outputStream;
        //Caso a ArrayList recebida esteja vazia elimina o ficheiro para quando é carregado não se leia "lixo"
        if (ArrayListLivros.isEmpty()) {
            File myObj = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt");
            myObj.delete();
        } else {
            //Abrir o ficheiro
            //Percorrer a ArrayList objeto a objeto 
            //Para cada objeto adiciona-se a uma string temporária(tmp) e posteriormente escrver no ficheiro
            try {
                outputStream = new FileOutputStream("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt");
                ObjectOutputStream obj = new ObjectOutputStream(outputStream);
                for (int i = 0; i < ArrayListLivros.size(); i++) {
                    tmp = tmp + ArrayListLivros.get(i).getId() + " | " + ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | "
                            + ArrayListLivros.get(i).getEditora() + " | " + ArrayListLivros.get(i).getAutor() + " | " + ArrayListLivros.get(i).getAno() + " | "
                            + ArrayListLivros.get(i).getEdicao() + " | " + ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
                }
                obj.writeObject(tmp);
                obj.flush();
                obj.close();
                outputStream.close();
            } catch (FileNotFoundException ex) {
               System.out.println(ex.getMessage());
            } catch (IOException ex) {
               System.out.println(ex.getMessage());
            }
        }
    }

    public ArrayList<livro> carregarLivros() {//Método para carregar os livros do vendedor do respetivo ficheiro
        
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\Livros.txt");
        try {
            
            if (file.createNewFile()) {// Se for possível criar um ficheiro novo devolvemos uma lista vazia
                return listaFile;
            } else {
                try {
                    FileInputStream inputStream = new FileInputStream(file);
                    if (inputStream.available() != 0) {//Verificar se o ficheiro está vazio
                        
                        //Adicionar o conteúdo lido do ficheiro à ArrayList 
                        ObjectInputStream obj = new ObjectInputStream(inputStream);
                        String s = (String) obj.readObject();
                        lines = s.split("\r?\n");
                      
                        for (int i = 0; i < lines.length; i++) {
                            String[] part = lines[i].split("[|]");
                            
                            if (part[i] != null) {
                                livro l = new livro();

                                l.setId(Integer.parseInt(part[0].trim()));
                                l.setNome(part[1].trim());
                                l.setGenero(part[2].trim());
                                l.setEditora(part[3].trim());
                                l.setAutor(part[4].trim());
                                l.setAno(Integer.parseInt(part[5].trim()));
                                l.setEdicao(Integer.parseInt(part[6].trim()));
                                l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                                l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                                listaFile.add(l);
                            }
                        }
                        obj.close();
                    }
                    inputStream.close();

                }catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }catch (ClassNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosVendidos() {//Método para carregar os livros vendidos pelo vendedor do respetivo ficheiro
      
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosVendidos.txt");
        try {
            if (file.createNewFile()) {// Se for possível criar um ficheiro novo devolvemos uma lista vazia
                return listaFile;
            }else{
                try {
                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {//Verificar se o ficheiro está vazio
                        //Adicionar o conteúdo lido do ficheiro à ArrayList 
                        ObjectInputStream obj = new ObjectInputStream(inputStream);
                        String s = (String) obj.readObject();
                        lines = s.split("\r?\n");
                        for (int i = 0; i < lines.length; i++) {

                            String[] part = lines[i].split("[|]");

                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                        }
                        obj.close();
                    }
                    inputStream.close();
                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                } catch (ClassNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosComprados() {//Método para carregar os livros comprados pelo vendedor ao fornecdor do respetivo ficheiro
        
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosComprados.txt");
        try {
            if (file.createNewFile()) {// Se for possível criar um ficheiro novo devolvemos uma lista vazia
                return listaFile;
            }else {

                try {

                    FileInputStream inputStream = new FileInputStream(file);

                    if (inputStream.available() != 0) {//Verificar se o ficheiro está vazio
                        //Adicionar o conteúdo lido do ficheiro à ArrayList 
                        ObjectInputStream obj = new ObjectInputStream(inputStream);
                        String s = (String) obj.readObject();
                        lines = s.split("\r?\n");

                        for (int i = 0; i < lines.length; i++) {
                            String[] part = lines[i].split("[|]");
                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                        }
                        obj.close();
                    }
                    inputStream.close();
                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                } catch (ClassNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }

            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return listaFile;
    }

    public ArrayList<livro> carregarLivrosFornecedor() {//Método para carregar os livros em stock do fornecdor do respetivo ficheiro
        
        ArrayList<livro> listaFile = new ArrayList<livro>();
        File file = new File("C:\\SISTEMASDISTRIBUIDOS\\TP1_SisDis\\src\\tp1_sisdis\\LivrosFornecedor.txt");
        try {
            if (file.createNewFile()) {// Se for possível criar um ficheiro novo devolvemos uma lista vazia
                return listaFile;
            }else {
                try {

                    FileInputStream inputStream = new FileInputStream(file);
                    if (inputStream.available() != 0) {//Verificar se o ficheiro está vazio
                        //Adicionar o conteúdo lido do ficheiro à ArrayList 
                        ObjectInputStream obj = new ObjectInputStream(inputStream);
                        String s = (String) obj.readObject();

                        lines = s.split("\r?\n");

                        for (int i = 0; i < lines.length; i++) {
                           
                            String[] part = lines[i].split("[|]");
                            livro l = new livro();

                            l.setId(Integer.parseInt(part[0].trim()));
                            l.setNome(part[1].trim());
                            l.setGenero(part[2].trim());
                            l.setEditora(part[3].trim());
                            l.setAutor(part[4].trim());
                            l.setAno(Integer.parseInt(part[5].trim()));
                            l.setEdicao(Integer.parseInt(part[6].trim()));
                            l.setPrecoCompra(Float.parseFloat(part[7].trim()));
                            l.setPrecoVenda(Float.parseFloat(part[8].trim()));
                            listaFile.add(l);
                        }
                        obj.close();
                    }
                    inputStream.close();
                }catch (FileNotFoundException ex) {
                   System.out.println(ex.getMessage());
                }catch (IOException ex) {
                   System.out.println(ex.getMessage());
                }catch (ClassNotFoundException ex) {
                   System.out.println(ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return listaFile;
    }
}
