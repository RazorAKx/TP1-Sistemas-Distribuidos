package sdtp1;
import java.rmi.Naming;
import java.rmi.registry.*;
import java.rmi.server.*;


public class RMIServidor {
        public static void main(String[] argv) throws Exception{
       
       
        String name = "rmi://localhost:1099/Servidor";
        System.setSecurityManager(new SecurityManager()); //Criar e instalar um gestor de segurança
        try{
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            
            System.out.println("Server is ready. ");
            
            VendedorImpl vendedor = new VendedorImpl(name);

            Naming.rebind("rmi://localhost:1099/Servidor", vendedor);
   
        }catch(Exception e){
            System.out.println("Trouble: " + e);
        }
    }
    
}
