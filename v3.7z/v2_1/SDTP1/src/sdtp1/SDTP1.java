package sdtp1;


public class SDTP1 {

    public static void main(String[] args) {
        
        
    }
}
