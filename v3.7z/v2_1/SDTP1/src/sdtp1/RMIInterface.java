package sdtp1;

import java.util.*;


public interface RMIInterface extends java.rmi.Remote{
    public void addLivro (livro l) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarLivros() throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorNome(String nome) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorGenero(String gen) throws java.rmi.RemoteException;
    public void eliminarLivro(int id) throws java.rmi.RemoteException;
    public int quantidadeLivro(int id) throws java.rmi.RemoteException;
    public void VenderLivro(int id) throws java.rmi.RemoteException;


}
