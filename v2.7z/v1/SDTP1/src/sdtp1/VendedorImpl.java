/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdtp1;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
/**
 *
 * @author bruno
 */
public class VendedorImpl extends UnicastRemoteObject implements RMIInterface{
    ArrayList <livro> ArrayListLivros = new ArrayList<livro>();
    int count =0;
    
     public VendedorImpl(String name) throws java.rmi.RemoteException{
        super();
        
        try{
            Naming.rebind(name, this);
        }catch(Exception e){
            if (e instanceof RemoteException)
                throw (RemoteException)e;
            else
                throw new RemoteException(e.getMessage());
        }
    }public void addLivro(livro l){
       ArrayListLivros.add(l);
    }
    public ArrayList<livro> consultarLivros(){
        return ArrayListLivros;
    }
    
    public ArrayList<livro> consultarPorNome(String nome){
        ArrayList<livro> livros= new ArrayList<livro>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if(nome.equals(ArrayListLivros.get(i).getNome()))
                livros.add(ArrayListLivros.get(i));
        }
        return livros;
    }
    public ArrayList<livro> consultarPorGenero(String gen){
        
        ArrayList<livro> livros= new ArrayList<livro>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if(gen.equals(ArrayListLivros.get(i).getGenero()))
                livros.add(ArrayListLivros.get(i));
        }
        return livros;
    }
    public void eliminarLivro(int id){
        int count=0;
        ArrayList<livro> livros= new ArrayList<livro>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                livros.add(ArrayListLivros.get(i));
                count++;
            }
        }
        System.out.println("eliminei " + count);
        ArrayListLivros.removeAll(livros);
    } 
    
    
    public int quantidadeLivro(int id){
        ArrayList<livro> livros= new ArrayList<livro>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                count++;
            }
        }   
        return count;
    }
    
}
