/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdtp1;

import java.util.*;

/**
 *
 * @author bruno
 */
public interface RMIInterface extends java.rmi.Remote{
    public void addLivro (livro l) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarLivros() throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorNome(String nome) throws java.rmi.RemoteException;
    public ArrayList<livro> consultarPorGenero(String gen) throws java.rmi.RemoteException;
    public void eliminarLivro(int id) throws java.rmi.RemoteException;
    public int quantidadeLivro(int id) throws java.rmi.RemoteException;
}
