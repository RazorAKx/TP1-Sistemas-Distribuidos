package sdtp1;

import java.util.Date;

public class venda {
    private int id, idVendedor, idLivro;
    private Date dataVenda;
}
