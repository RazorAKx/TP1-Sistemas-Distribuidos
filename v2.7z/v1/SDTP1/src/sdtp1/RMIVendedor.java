/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdtp1;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;


/**
 *
 * @author bruno
 */
public class RMIVendedor {
    
        public static livro AdicionarLivro(){
            livro l;
            Scanner s = new Scanner(System.in); 
            String nome="",autor="",genero="",editora="";
            int id=0,ano,edicao;
            float precocompra=0,precovenda=0;
            
            System.out.println("Id:");
            id=s.nextInt();
            s.nextLine();
            System.out.println("Nome:");
            nome=s.nextLine();
            System.out.println("Género:");
            genero=s.nextLine();
            System.out.println("Editora:");
            editora=s.nextLine();
            System.out.println("Autor(a):");
            autor=s.nextLine();
            System.out.println("Ano:");
            ano=s.nextInt();
            s.nextLine();
            System.out.println("Edição:");
            edicao=s.nextInt();
            s.nextLine();
            System.out.println("Preço de Compra:");
            precocompra=s.nextFloat();
            s.nextLine();
            System.out.println("Preço de Venda:");
            precovenda=s.nextFloat();
            s.nextLine();

            l=new livro(id,nome,genero,editora,autor,ano,edicao,precocompra,precovenda);
            
            return l;
        }
        public static int RemoverLivro(){
            Scanner s = new Scanner (System.in);
            int x;
            System.out.println("Introduza o id do livro que pretende remover:");
            x=s.nextInt();
            s.nextLine();
            
            return x;
        }
    
        public static void main(String[] argv) throws Exception{
         System.setSecurityManager(new SecurityManager());
         
         try{
            RMIInterface vendedorRemoto;
            vendedorRemoto = (RMIInterface) Naming.lookup("rmi://localhost:1099/Servidor");
            int option=-1;
            Scanner s = new Scanner(System.in);
            while(true){
            do{
                System.out.println("Menu Vendedor"); //ver aas cores 
                System.out.println("1-Adicionar Livro");
                System.out.println("2-Remover Livro");  //remover todos os livros com um id fornecido
                System.out.println("3-Vender Livro");
                System.out.println("4-Consultar Todos os Livros");
                System.out.println("5-Consultar Livro por nome");
                System.out.println("6-Consultar Livro por genero");
                System.out.println("7-Verificar Quantidade de um dado Livro");
                System.out.println("8-Consultar Vendas efectuadas");
                System.out.println("9-Consultar Compras efetuadas");
                
                System.out.println("\n0-Sair\n");
                System.out.print("Introduza a opção: ");
                option=s.nextInt();
                System.out.println("");
            }while(option<0 || option >9);
            
            switch(option){
                case 1:
                    vendedorRemoto.addLivro(AdicionarLivro());
                    break;
                case 2:
                    vendedorRemoto.eliminarLivro(RemoverLivro());
                    break;
                case 3:
                    break;
                case 4:
                    System.out.println(vendedorRemoto.consultarLivros());
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                    break;
                case 0:
                    System.out.println("Obrigado, volte sempre :)");
                    System.exit(0);
                    //fechar o rmi ou so deixar
                    break;
            }
            }
           /* 
            livro l = new livro(1,"teste","terror","merda","russo",1986,55,(float)22.5,(float)25);
            livro l2 = new livro(2,"penis","terror","porto","italiano",2021,55,(float)59,(float)69);
            livro l3 = new livro(3,"vaca","terror","quinta","russo",1986,55,(float)22.5,(float)25);
            livro l4 = new livro(4,"codefordummies","terror","merda","russo",1986,55,(float)22.5,(float)25);
            livro l5 = new livro(5,"aprendejavacomaprata","java","merda","russo",1986,55,(float)22.5,(float)25);
            livro l6 = new livro(6,"paulvocetaai","so","merda","russo",1986,55,(float)22.5,(float)25);
            livro l7 = new livro(7,"vaca","sexual","turmasd","prata",2021,55,(float)22.5,(float)25);
            livro l8 = new livro(8,"vaca","sexual","turmasd","prata",2021,55,(float)22.5,(float)25);
            
            vendedorRemoto.addLivro(l);
            vendedorRemoto.addLivro(l2);
            vendedorRemoto.addLivro(l3);
            vendedorRemoto.addLivro(l4);
            vendedorRemoto.addLivro(l5);
            vendedorRemoto.addLivro(l6);
            vendedorRemoto.addLivro(l7);
            vendedorRemoto.addLivro(l7);
            vendedorRemoto.addLivro(l8);
            */
             //System.out.println("livros: \n" + vendedorRemoto.consultarLivros());
             //System.out.println("consultar livros por nome: \n " + vendedorRemoto.consultarPorNome("vaca").toString());
             //System.out.println("consultar livros por gen: \n" + vendedorRemoto.consultarPorGenero("terror").toString());
             //System.out.println("quantidade de livros: \n" + vendedorRemoto.quantidadeLivro(7));
             
             //vendedorRemoto.eliminarLivro(7);
             //System.out.println("livros: \n" + vendedorRemoto.consultarLivros());
             
             
         
         }catch(RemoteException re){
            
            System.out.println("RemoteException");
            System.out.println(re.getMessage());
         }
    }  
}
