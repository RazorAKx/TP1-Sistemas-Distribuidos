package sdtp1;

import java.io.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class VendedorImpl extends UnicastRemoteObject implements RMIInterface{
    ArrayList <livro> ArrayListLivros = new ArrayList<>();
    int count =0; //este era para contar a quantidade de livros que há com um certo id
    int numeroVendas=0;
    
    
     public VendedorImpl(String name) throws java.rmi.RemoteException{
        super();
        
        try{
            Naming.rebind(name, this);
        }catch(Exception e){
            if (e instanceof RemoteException)
                throw (RemoteException)e;
            else
                throw new RemoteException(e.getMessage());
        }
    }
     
    public void addLivro(livro l){
            ArrayListLivros.add(l);
            
            System.out.println("Livro adicionado: '" + l.getNome() + "'"); 
    }
    
    public void vendeLivro(int id){
        String nome = "";
        //Remover livro da arraylist
        //E depois adicionar à lista de vendas
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                nome = ArrayListLivros.get(i).getNome();
                ArrayListLivros.remove(i);
            }
        }
        System.out.println("Livro vendido: '" + nome + "'");
    }
    
    public ArrayList<livro> consultarLivros(){
        //adicionar a aarry list toda nao so um obj do tipo file
        return ArrayListLivros;
    }
    
    public ArrayList<livro> consultarPorNome(String nome){
        ArrayList<livro> livros= new ArrayList<>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if(nome.equals(ArrayListLivros.get(i).getNome()))
                livros.add(ArrayListLivros.get(i));
        }
        return livros;
    }
    
    public ArrayList<livro> consultarPorGenero(String gen){
        
        ArrayList<livro> livros= new ArrayList<>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if(gen.equals(ArrayListLivros.get(i).getGenero()))
                livros.add(ArrayListLivros.get(i));
        }
        return livros;
    }
    public void eliminarLivro(int id){
        int count=0;
        ArrayList<livro> livros= new ArrayList<>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                livros.add(ArrayListLivros.get(i));
                count++;
            }
        }
        System.out.println("eliminei " + count);
        ArrayListLivros.removeAll(livros);
    } 
    
    public int quantidadeLivro(int id){
        ArrayList<livro> livros= new ArrayList<>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                count++;
            }
        }   
        return count;
    }
 
    public void VenderLivro(int id){
        int count=0;
        ArrayList<livro> livros= new ArrayList<>();
        for(int i=0;i<ArrayListLivros.size();i++ ){
            if((ArrayListLivros.get(i).getId())==id){
                livros.add(ArrayListLivros.get(i));
                count++;
                numeroVendas++;
            }
        }
        System.out.println("vendi " + count);
        ArrayListLivros.removeAll(livros);
            
    } 
    
    public livro ProcuraLivro(int id){
        for(int i=0;i<ArrayListLivros.size();i++){
            if((ArrayListLivros.get(i).getId())==id)
                return ArrayListLivros.get(i);
         
        }
        return null;
    }
   
    
}