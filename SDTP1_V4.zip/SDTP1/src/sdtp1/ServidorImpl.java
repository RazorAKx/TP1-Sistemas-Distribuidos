/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdtp1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author bruno
 */
public class ServidorImpl extends UnicastRemoteObject implements RMIInterfaceServidor{
    ArrayList <livro> ArrayListLivros = new ArrayList<>();
    
    public void GuardarFicheiro(){
        try{
                FileOutputStream outputStream = new FileOutputStream ("C:\\Users\\bruno\\Downloads\\v2_1\\SDTP1\\teste.txt");
                ObjectOutputStream  obj = new ObjectOutputStream(outputStream);
                String tmp = "";
                for (int i = 0; i < ArrayListLivros.size() ; i++){
                    tmp = tmp + ArrayListLivros.get(i).getId()+ " | " +ArrayListLivros.get(i).getNome() + " | " + ArrayListLivros.get(i).getGenero() + " | " + ArrayListLivros.get(i).getEditora()+ " | " + ArrayListLivros.get(i).getAutor() + 
                            " | " + ArrayListLivros.get(i).getAno() + " | " + ArrayListLivros.get(i).getEdicao() + " | " +  ArrayListLivros.get(i).getPrecoCompra() + " | " + ArrayListLivros.get(i).getPrecoVenda() + "\n";
                }
                obj.writeObject(tmp);
                obj.flush();
                obj.close();
                //obj.writeObject(ArrayListLivros); //adicionar a aarry list toda nao so um obj do tipo file
            
            }catch (IOException e){
                e.printStackTrace();
            }       
    }
    
    
    public ArrayList<livro> LerFicheiro(){
        ArrayList <livro> listaFile = new ArrayList<livro>();
        try{
                FileInputStream inputStream = new FileInputStream ("C:\\Users\\bruno\\Downloads\\v2_1\\SDTP1\\teste.txt");
                ObjectInputStream obj = new ObjectInputStream(inputStream);
                
                String s="";
                s=obj.readLine();
                String[] part = s.split("[|]");
                
                
                while(s!=null || !s.isEmpty()){
                   
                livro l = new livro();
                l.setId(Integer.parseInt(part[0]));
                l.setNome(part[1]);
                l.setGenero(part[2]);
                l.setEditora(part[3]);
                l.setAutor(part[4]);
                l.setAno(Integer.parseInt(part[5]));
                l.setEdicao(Integer.parseInt(part[6]));
                l.setPrecoCompra(Float.parseFloat(part[7]));
                l.setPrecoVenda(Float.parseFloat(part[8]));

                listaFile.add(l);
                 
                }
             
            }catch (IOException e){
                e.printStackTrace();
            
        }
        
        return listaFile;
    }    
    
   public ServidorImpl(String name) throws java.rmi.RemoteException{
        super();
        
        try{
            Naming.rebind(name, this);
        }catch(Exception e){
            if (e instanceof RemoteException)
                throw (RemoteException)e;
            else
                throw new RemoteException(e.getMessage());
        }
    }
   
}