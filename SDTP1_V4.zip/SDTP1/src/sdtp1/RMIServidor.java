package sdtp1;
import java.rmi.Naming;
import java.rmi.registry.*;
import java.rmi.server.*;


public class RMIServidor {
        public static void main(String[] argv) throws Exception{
       
       
        String name = "rmi://localhost:1099/Vendedor";
        String s = "rmi://localhost:1099/Servidor";
        System.setSecurityManager(new SecurityManager()); //Criar e instalar um gestor de segurança
        //rmi files permission por no policy 
        try{
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            
            System.out.println("Server is ready. ");
            
            VendedorImpl vendedor = new VendedorImpl(name);
            ServidorImpl server = new ServidorImpl(s);

            Naming.rebind("rmi://localhost:1099/Vendedor", vendedor);
            Naming.rebind("rmi://localhost:1099/Servidor", server);
   
        }catch(Exception e){
            System.out.println("Trouble: " + e);
        }
    }
    
}
