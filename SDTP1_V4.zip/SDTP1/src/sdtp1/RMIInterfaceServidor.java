/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdtp1;

import java.util.ArrayList;

/**
 *
 * @author bruno
 */
public interface RMIInterfaceServidor extends java.rmi.Remote{
    public void GuardarFicheiro() throws java.rmi.RemoteException;
    public ArrayList<livro> LerFicheiro() throws java.rmi.RemoteException;
}
